<?php 
require_once('vendor/autoload.php');
$stripe = new \Stripe\StripeClient('sk_test_51LCrEBJPfbfzje02NYceKQNcxkYCocbDdLhdwJ3xMxBpvzy9xmFYBzZ247lVepjce5RXb2Pb8xny6fSdiis1Ugtf00eVLsnICw');

echo "<pre>";
print_r($stripe->customers->all(['limit' => 3]));
echo "</pre>";

$stripe->customers->delete(
    'cus_MzZEfsFKaeJIJn',
    []
  );
?>